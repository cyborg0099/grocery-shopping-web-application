
import p4_img from "./product_4.jpeg";


import p9_img from "./product_9.jpg";
import p30_img from "./product_30.jpg";

import p42_img from "./product_42.jpg";
import p46_img from "./product_46.jpg";
import p16_img from "./product_16.jpg";
import p45_img from "./product_45.jpg";
import p24_img from "./product_24.jpg";






let new_collections = [
  {
    id: 12,
    name: "Soya Beans",
    image: p9_img,
    new_price: 85.0,
    old_price: 120,
  },
  {
    id: 35,
    name: "Fogg Body Perfume",
    image: p42_img,
    new_price: 85.0,
    old_price: 120.5,
  },
  {
    id: 14,
    name: "Ginger",

    image: p46_img,
    new_price: 20.0,
    old_price: 45.5,
  },
  {
    id: 8,
    name: "Cereals and Musli",
    image: p16_img,
    new_price: 299.0,
    old_price: 399.5,
  },
  {
    id: 15,
    name: "Bottle Gourd(Lauki)",
    image: p45_img,
    new_price: 15.0,
    old_price: 20.5,
  },
  {
    id: 2,
    name: "pasta and Noodles",
    image: p4_img,
    new_price: 99.0,
    old_price: 125.5,
  },
  {
    id: 17,
    name: "Apple",
    image: p30_img,
    new_price: 150.0,
    old_price: 170.5,
  },
  {
    id: 28,
    name: "Dettol Dish Wash",
    image: p24_img,
    new_price: 85.0,
    old_price: 99.5,
  },
];

export default new_collections;
