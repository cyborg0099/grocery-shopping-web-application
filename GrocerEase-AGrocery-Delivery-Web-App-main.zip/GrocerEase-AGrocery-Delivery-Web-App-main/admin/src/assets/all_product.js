import p1_img from "./product_1.jpeg";
import p2_img from "./product_2.png";
// import p3_img from "./product_3.jpeg";
import p4_img from "./product_4.jpeg";
import p5_img from "./product_5.jpg";
import p6_img from "./product_6.jpeg";
import p7_img from "./product_7.jpg";
import p8_img from "./product_8.png";
import p9_img from "./product_9.jpg";
// import p10_img from "./product_10.jpg";
// import p11_img from "./product_11.jpg";
// import p12_img from "./product_12.jpg";
import p13_img from "./product_13.jpg";
// import p14_img from "./product_14.jpg";
import p15_img from "./product_15.jpg";
import p16_img from "./product_16.jpg";
// import p17_img from "./product_17.jpg";
// import p18_img from "./product_18.jpg";
// import p19_img from "./product_19.jpg";
// import p20_img from "./product_20.jpg";
import p21_img from "./product_21.jpg";
import p22_img from "./product_22.jpg";
import p23_img from "./product_23.jpg";
import p24_img from "./product_24.jpg";
// import p25_img from "./product_25.jpg";
import p26_img from "./product_26.jpg";
// import p27_img from "./product_27.jpg";
import p28_img from "./product_28.jpg";
import p29_img from "./product_29.jpg";
import p30_img from "./product_30.jpg";
import p31_img from "./product_31.jpg";
import p32_img from "./product_32.jpg";
// import p33_img from "./product_33.jpg";
import p34_img from "./product_34.jpg";
import p35_img from "./product_35.jpg";
import p36_img from "./product_36.jpg";
import p37_img from "./product_37.jpg";
import p38_img from "./product_38.jpg";
import p39_img from "./product_39.jpg";
import p40_img from "./product_40.jpg";
import p41_img from "./product_41.jpg";
import p42_img from "./product_42.jpg";
import p43_img from "./product_43.jpg";
import p44_img from "./product_44.jpg";
import p45_img from "./product_45.jpg";
import p46_img from "./product_46.jpg";
import p47_img from "./product_47.jpg";
import p48_img from "./product_48.jpeg";
import p49_img from "./product_49.jpg";
import p50_img from "./product_50.jpg";
import p51_img from "./product_51.jpg";
import p52_img from "./product_52.jpg";
import p53_img from "./product_53.jpg";
import p54_img from "./product_54.jpg";
import p55_img from "./product_55.jpg";





let all_product = [
  {
    id: 1,
    name: "Kellogs OATS 1Kg Pack",
    category: "Snacks",
    image: p1_img,
    new_price: 199.0,
    old_price: 249.5,
  },
  {
    id: 2,
    name: "pasta and Noodles",
    category: "Snacks",
    image: p4_img,
    new_price: 99.0,
    old_price: 125.5,
  },
  {
    id: 3,
    name: "Bikaji Bhujiya",
    category: "Snacks",
    image: p5_img,
    new_price: 77.0,
    old_price: 100.5,
  },
  {
    id: 4,
    name: "Tea",
    category: "Snacks",
    image: p6_img,
    new_price: 100.0,
    old_price: 150.0,
  },
  {
    id: 5,
    name: "Corn Flex for Lighter morning",
    category: "Snacks",
    image: p7_img,
    new_price: 50.0,
    old_price: 79.5,
  },
  {
    id: 6,
    name: "Chocos",
    category: "Snacks",
    image: p8_img,
    new_price: 49.0,
    old_price: 120.5,
  },
  {
    id: 7,
    name: "Real Juice",
    category: "Snacks",
    image: p15_img,
    new_price: 85.0,
    old_price: 120.5,
  },
  {
    id: 8,
    name: "Cereals and Musli",
    category: "Snacks",
    image: p16_img,
    new_price: 299.0,
    old_price: 399.5,
  },
  {
    id: 9,
    name: "Amul butter",
    category: "Snacks",
    image: p22_img,
    new_price: 66.0,
    old_price: 87.5,
  },
  {
    id: 10,
    name: "Bread",
    category: "Snacks",
    image: p48_img,
    new_price: 50.0,
    old_price: 60.0,
  },
  {
    id: 11,
    name: "Penut butter and Jam",
    category: "Snacks",
    image: p2_img,
    new_price: 599.0,
    old_price: 799.0,
  },
  {
    id: 12,
    name: "Soya Beans",
    category: "Snacks",
    image: p9_img,
    new_price: 55.0,
    old_price: 60.0,
  },
  {
    id: 13,
    name: "Tomatos",
    category: "Vegetables",
    image: p43_img,
    new_price: 35.0,
    old_price: 50.5,
  },
  {
    id: 14,
    name: "ginger",
    category: "Vegetables",
    image: p46_img,
    new_price: 20.0,
    old_price: 45.5,
  },
  {
    id: 15,
    name: "Bottle Gourd(Lauki)",
    category: "Vegetables",
    image: p45_img,
    new_price: 15.0,
    old_price: 20.5,
  },
  {
    id: 16,
    name: "Carrot",
    category: "Vegetables",
    image: p47_img,
    new_price: 55.0,
    old_price: 70.5,
  },
  {
    id: 17,
    name: "Apple",
    category: "Vegetables",
    image: p30_img,
    new_price: 150.0,
    old_price: 170.5,
  },
  {
    id: 18,
    name: "Banana",
    category: "Vegetables",
    image: p44_img,
    new_price: 40.0,
    old_price: 60.0,
  },
  {
    id: 19,
    name: "Potato",
    category: "Vegetables",
    image: p49_img,
    new_price: 35.0,
    old_price: 40.0,
  },
  {
    id: 20,
    name: "LadyFingers",
    category: "Vegetables",
    image: p50_img,
    new_price: 25.0,
    old_price: 30.5,
  },
  {
    id: 21,
    name: "Chilis",
    category: "Vegetables",
    image: p51_img,
    new_price: 85.0,
    old_price: 120.5,
  },
  {
    id: 22,
    name: "Mashrooms",
    category: "Vegetables",
    image: p52_img,
    new_price: 100.0,
    old_price: 120.5,
  },
  {
    id: 23,
    name: "Pomegranate",
    category: "Vegetables",
    image: p53_img,
    new_price: 150.0,
    old_price: 199.0,
  },
  {
    id: 24,
    name: "Broccoli",
    category: "Vegetables",
    image: p54_img,
    new_price: 85.0,
    old_price: 120.5,
  },
  {
    id: 25,
    name: "Dettol",
    category: "HouseHolds",
    image: p21_img,
    new_price: 120.0,
    old_price: 145.5,
  },
  {
    id: 26,
    name: "Tata Salt",
    category: "HouseHolds",
    image: p23_img,
    new_price: 50.0,
    old_price: 120.5,
  },
  {
    id: 27,
    name: "Soya Beans",
    category: "HouseHolds",
    image: p9_img,
    new_price: 75.0,
    old_price: 99.5,
  },
  {
    id: 28,
    name: "Dettol Dish Wash",
    category: "HouseHolds",
    image: p24_img,
    new_price: 85.0,
    old_price: 99.5,
  },
  {
    id: 29,
    name: "Nivia Body Loations",
    category: "HouseHolds",
    image: p28_img,
    new_price: 199.0,
    old_price: 220.5,
  },
  {
    id: 30,
    name: "Himalaya Neem Fash Wash",
    category: "HouseHolds",
    image: p29_img,
    new_price: 75.0,
    old_price: 90.5,
  },
  {
    id: 31,
    name: "Vim Dish Wash",
    category: "HouseHolds",
    image: p31_img,
    new_price: 85.0,
    old_price: 120.5,
  },
  {
    id: 32,
    name: "Nivia Body Freshner",
    category: "HouseHolds",
    image: p39_img,
    new_price: 155.0,
    old_price: 170.5,
  },
  {
    id: 33,
    name: "Vasiline Body Lotion",
    category: "HouseHolds",
    image: p40_img,
    new_price: 245.0,
    old_price: 270.5,
  },
  {
    id: 34,
    name: "Dove Body Lotion",
    category: "HouseHolds",
    image: p41_img,
    new_price: 200.0,
    old_price: 220.5,
  },
  {
    id: 35,
    name: "Fogg Body Perfume",
    category: "HouseHolds",
    image: p42_img,
    new_price: 150.0,
    old_price: 190.5,
  },
  {
    id: 36,
    name: "Wheel",
    category: "HouseHolds",
    image: p55_img,
    new_price: 85.0,
    old_price: 120.5,
  },



  {
    id: 37,
    name: "Thumsup",
    category: "Snacks",
    image: p32_img,
    new_price: 50.0,
    old_price: 60.5,
  },
  {
    id: 38,
    name: "Limca",
    category: "Snacks",
    image: p26_img,
    new_price: 40.0,
    old_price: 50.5,
  },
  {
    id: 39,
    name: "Cocacola",
    category: "ColdDrinks",
    image: p34_img,
    new_price: 50.0,
    old_price: 55.5,
  },
  {
    id: 40,
    name: "Maza",
    category: "ColdDrinks",
    image: p35_img,
    new_price: 60.0,
    old_price: 70.5,
  },
  {
    id: 40,
    name: "Sprite",
    category: "ColdDrinks",
    image: p36_img,
    new_price: 40.0,
    old_price: 45.5,
  },
  {
    id: 42,
    name: "Red Bull",
    category: "Snacks",
    image: p13_img,
    new_price: 125.0,
    old_price: 130.5,
  },
  {
    id: 43,
    name: "Appy",
    category: "Snacks",
    image: p37_img,
    new_price: 20.0,
    old_price: 22.5,
  },
  {
    id: 44,
    name: "Soda",
    category: "Snacks",
    image: p38_img,
    new_price: 20.0,
    old_price: 25.5,
  },
  
];

export default all_product;
