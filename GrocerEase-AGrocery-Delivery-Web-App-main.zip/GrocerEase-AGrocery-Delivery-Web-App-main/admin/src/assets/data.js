import p1_img from './product_1.jpeg'
// import p2_img from './product_2.png'
// import p3_img from './product_3.jpeg'
import p4_img from './product_4.jpeg'
import p5_img from "./product_5.jpg";
import p6_img from "./product_6.jpeg";


let data_product = [
  {
    id:1,
    name:"Kellogs OATS 1kg pack",
    image:p1_img,
    new_price: 199.0,
    old_price: 249.5,
  },
  {id:2,
    name:"Maggie and Pasta Combo Pack",
    image:p4_img,
    new_price: 99.0,
    old_price: 125.5,
  },
  {id:3,
    name:"Bikaji Bhujiya ",
    image:p5_img,
    new_price: 77.0,
    old_price: 100.5,
  },
  {id:4,
    name:"Tea",
    image:p6_img,
    new_price: 100.0,
    old_price: 150.0,
  },
];

export default data_product;
